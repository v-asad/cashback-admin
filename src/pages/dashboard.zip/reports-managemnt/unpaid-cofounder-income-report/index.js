import TextField from '@mui/material/TextField'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { DataGrid } from '@mui/x-data-grid'
import Card from '@mui/material/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from 'src/hooks/useAuth'
import CardContent from '@mui/material/CardContent'
import Icon from 'src/@core/components/icon'
const UnPaidCoFounderReport = () => {
  const auth = useAuth()
  const [data, setData] = useState([])
  const [totalCommision, settotalCommision] = useState([])
  const loadData = () => {
    axios
      .get(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/report-management/unpaid-cofounder-income`, {
        headers: {
          Authorization: `Bearer ${localStorage.accessToken}`
        }
      })
      .then(response => {
        settotalCommision(response.data.totalCommision)
        const tempData = response.data.data.map((d, key) => {
          return { key, ...d }
        })
        setData(tempData)
      })
      .catch(error => {
        
        toast.error(
          `${error.response ? error.response.status : ''}: ${error.response ? error.response.data.message : error}`
        )
        if (error.response && error.response.status == 401) {
          auth.logout()
        }
      })
  }
  useEffect(() => {
    loadData()
  }, [])
  const columns = [
    { field: '', headerName: '#', width: 100, renderCell: params => params.row.key + 1 },
    { field: 'userId', headerName: ' UserId', width: 200 },
    {
      field: 'username',
      headerName: 'USERNAME',
      width: 250,
  
    },
    { field: 'purchasedAmount', headerName: 'PurchasedAmount', width: 200 },
    {
      field: 'percentage',
      headerName: 'percentage',
      width: 250,
      
    },
    { field: 'amount', headerName: 'amount', width: 150,},
    { field: 'remark', headerName: 'remark', width: 150, },
    { field: 'purchasedInvoice', headerName: 'purchased Invoice', width: 150, },
    { field: 'date', headerName: 'date', width: 250,renderCell:params=> new Date(params.row.date).toLocaleDateString() },
    
  ]
  return (
    <>
    <Grid item xs={12}>
        <Box >
          <Typography variant='h5' sx={{my:8}}>Unpaid Co-Founder Income Report  </Typography>

        </Box>
      </Grid>

     
      
      <Card component='div' sx={{ position: 'relative', mb: 7 }}>
      <CardContent>
         <DataGrid rows={data} columns={columns} pageSize={10} getRowId={(row) => row.key} rowsPerPageOptions={[10]} autoHeight />
         <Typography variant='div' sx={{ my: 2, fontWeight: 'bold',display:'block' }}>
              Total Commission= {totalCommision}
              </Typography>
         </CardContent>
      </Card>
    </>
  )
}

export default UnPaidCoFounderReport
