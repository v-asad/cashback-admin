import TextField from '@mui/material/TextField'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { DataGrid } from '@mui/x-data-grid'
import Card from '@mui/material/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from 'src/hooks/useAuth'
import CardContent from '@mui/material/CardContent'
import Icon from 'src/@core/components/icon'
const ChangeProfilePhoto = () => {
 
  return (
    <>
      <Card component='div' sx={{ position: 'relative', mb: 7 }}>
        <CardContent>
          <Grid item xs={12}>
            <Box>
              <Typography variant='h5' sx={{ my: 8 }}>
              Change Profile Picture
              </Typography>
            </Box>
          </Grid>

          <Grid container spacing={3}>
         
          <Grid item md={9} xs={12}>
      <Button variant='contained' sx={{ mr: 2 }} component='label'>
        Upload Image
        <input hidden accept='image/*' multiple type='file' />
       
      </Button>
           Group 243.png have been uploaded
      </Grid>
            

            <Grid item  xs={12}>
              <Button variant='contained' sx={{ mr: 2 }}>
                Submit
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </>
  )
}

export default ChangeProfilePhoto
