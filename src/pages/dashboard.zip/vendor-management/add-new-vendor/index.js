import TextField from '@mui/material/TextField'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { DataGrid } from '@mui/x-data-grid'
import Card from '@mui/material/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from 'src/hooks/useAuth'
import CardContent from '@mui/material/CardContent'
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material'
import Icon from 'src/@core/components/icon'
import { toast } from 'react-hot-toast'
import { useRouter } from 'next/router'

const AddNewVendor = () => {
  const auth = useAuth()
  const [services, setServices] = useState([])
  const [countries, setCountries] = useState([])
  const [country, setCountry] = useState(null)
  const [username, setUsername] = useState(null)
  const [password, setPassword] = useState(null)
  const [description, setDescription] = useState(null)
  const [companyName, setCompanyName] = useState(null)
  const [companyRegistrationNo, setCompanyRegistrationNo] = useState(null)
  const [email, setEmail] = useState(null)
  const [state, setState] = useState(null)
  const [city, setCity] = useState(null)
  const [address, setAddress] = useState(null)
  const [phonecode, setPhonecode] = useState(null)
  const [telephone, setTelephone] = useState(null)
  const [landmark, setLandmark] = useState(null);
  const [service, setService] = useState(null);
  const [serviceTitle, setServiceTitle] = useState(null);
  const [serviceDescription, setServiceDescription] = useState(null);
  const [creditLimit, setCreditLimit] = useState(null);
  const [commision, setCommision] = useState(null);
  const [location, setLocation] = useState(null);
  const router = useRouter()
  const loadServices = () => {
    axios.get(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/vendor/services`, {
      headers: {
        "Authorization": `Bearer ${localStorage.accessToken}`
      }
    })
      .then(response => {
        setServices(response.data)
      })
      .catch(error => {
        if(error.response && error.response.data){
          if(error.response.data && error.response.data.message){
            toast.error(`${error.response? error.response.status:''}: ${error.response?error.response.data.message:error}`);
          }
          if(error.response.data && error.response.data.errors){
            error.response.data.errors.map(err => toast.error(err.msg))
          }
        }
        if (error.response && error.response.status == 401) {
          auth.logout();
        }
      })
  }

  const loadCountries = () => {
    axios.get(`${process.env.NEXT_PUBLIC_API_URL}/countries`)
      .then(response => {
        setCountries(response.data)
      })
      .catch(error => {
        toast.error(`${error.response? error.response.status:''}: ${error.response?error.response.data.message:error}`);
      })
  }
  useEffect(() => {
    loadServices()
    loadCountries()
  }, [])
  const handleCountryChange = (event) => {
    setCountry(event.target.value)
    countries.forEach(c=>{
      if(c.name == event.target.value){
        setPhonecode(c.phonecode)
      }
    })
  }

  const handleServiceChange = (event) => {
    setService(event.target.value)
  }

  const submitProfileHandler = (event) => {
    let updateArr = {
        "username": username,
        "password": password,
        "discription": description,
        "franchise_category": "Normal Franchise",
        "company_reg_no": companyRegistrationNo,
        "first_name": companyName,
        "email": email,
        "country": country,
        "state": state,
        "city": city,
        "address": address,
        "phonecode": phonecode,
        "telephone": telephone,
        "lendmark": landmark,
        "service": {
            "id": [service],
            "title": [serviceTitle],
            "discription": [serviceDescription]
        },
        "commission_percent": commision,
        "credit_limit": creditLimit,
        "location": location,
        "sex": "male"
    }
    axios.post(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/vendor/create`, updateArr, {
      headers: {
        "Authorization": `Bearer ${localStorage.accessToken}`
      }
    })
      .then(resp => {
        let data = resp.data
        if(data.success){
          toast.success(data.message)
          router.replace('/vendor-management/vendor-list/')
        }else{
          toast.error(data.message)
        }
      })
      .catch(error => {
        if(error.response && error.response.data){
          if(error.response.data && error.response.data.message){
            toast.error(`${error.response? error.response.status:''}: ${error.response?error.response.data.message:error}`);
          }
          if(error.response.data && error.response.data.errors){
            error.response.data.errors.map(err => toast.error(err.msg))
          }
        }
        if (error.response && error.response.status == 401) {
          auth.logout();
        }
      })
  }
  return (
    <>
      <Card component='div' sx={{ position: 'relative', mb: 7 }}>
        <CardContent>
          <Grid item xs={12}>
            <Box>
              <Typography variant='h5' sx={{ my: 8 }}>
                Vendor Registration Form
              </Typography>
            </Box>
          </Grid>

          <Grid container spacing={3}>
            <Grid item md={6} xs={12}>
              <TextField xs={6} fullWidth label='Username' onChange={(e) => setUsername(e.target.value)} value={username}  placeholder='Enter Username' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField xs={6} fullWidth label='Password' onChange={(e) => setPassword(e.target.value)} value={password} placeholder='Enter Password' />
            </Grid>
            <Grid item xs={12}>
              <TextField xs={6} fullWidth label='About Company' onChange={(e) => setDescription(e.target.value)} value={description} placeholder='About Company' />
            </Grid>
            <Grid item xs={12}>
            <Typography variant='h6' sx={{ my: 8 }}>
              Company Profile
            </Typography>
            </Grid>
          
            <Grid item md={6} xs={12}>
              <TextField xs={6} fullWidth label='Company Registration Number' onChange={(e) => setCompanyRegistrationNo(e.target.value)} value={companyRegistrationNo} placeholder='Company Registration Number' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField xs={6} fullWidth label='Company Name/Business Name' onChange={(e) => setCompanyName(e.target.value)} value={companyName} placeholder='Company Name/Business Name' />
            </Grid>
            <Grid item xs={12}>
              <TextField xs={6} fullWidth label='Email address' placeholder='Email address' onChange={(e) => setEmail(e.target.value)} value={email} />
            </Grid>
            <Grid item md={6} xs={12}>
              <Box sx={{ minWidth: 120 }}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Country</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    label="Country"
                    placeholder='Select Country'
                    onChange={handleCountryChange}
                  >
                    {countries.map(c=><MenuItem value={c.name} selected={c.name == country}>{c.name}</MenuItem>)}
                  </Select>
                </FormControl>
              </Box>
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField xs={6} fullWidth label='State' onChange={(e) => setState(e.target.value)} value={state} placeholder='State' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='City' placeholder='City' onChange={(e) => setCity(e.target.value)} value={city} />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label=' Full Address' placeholder='Full Address' onChange={(e) => setAddress(e.target.value)} value={address} />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Location(Google map link)' placeholder='Location(Google map link)' onChange={(e) => setLocation(e.target.value)} value={location} />
            </Grid>
            <Grid item md={2} xs={3}>
              <TextField fullWidth label='Phonecode' placeholder='Enter Phone code' disabled onChange={e => setPhonecode(e.target.value)} value={phonecode}  />
            </Grid>
            <Grid item md={4} xs={9}>
              <TextField fullWidth label='Mobile' onChange={(e) => setTelephone(e.target.value)} value={telephone} placeholder='Enter Mobile Phone' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Landmark' placeholder='Landmark' onChange={(e) => setLandmark(e.target.value)} value={landmark} />
            </Grid>
            {/* <Grid item md={6} xs={12}>
              <TextField fullWidth label='Product Gallery' placeholder='Product Gallery' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Brand Logo' placeholder='Brand Logo' />
            </Grid> */}

            <Grid item  xs={12}>
            <Typography variant='h6' sx={{ my: 8 }}>
              Our Service
            </Typography>
            </Grid>
            <Grid item md={3} xs={12}>
              <Box sx={{ minWidth: 120 }}>
                <FormControl fullWidth>
                  <InputLabel id="service-simple-select-label">Service</InputLabel>
                  <Select
                    labelId="service-simple-select-label"
                    id="service-simple-select"
                    label="Service"
                    placeholder='Select Service'
                    onChange={handleServiceChange}
                  >
                    {services.map(c=><MenuItem value={c.id}>{c.service_name}</MenuItem>)}
                  </Select>
                </FormControl>
              </Box>
            </Grid>
            <Grid item md={3} xs={12}>
              <TextField fullWidth label='Title' onChange={(e) => setServiceTitle(e.target.value)} value={serviceTitle} placeholder='Title' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Description' onChange={(e) => setServiceDescription(e.target.value)} value={serviceDescription} placeholder='Description' />
            </Grid>


            <Grid item xs={12}>
              <Button variant='contained' sx={{ mr: 2 }}>
                Add NEW
              </Button>
            </Grid>

            <Grid item  xs={12}>
            <Typography variant='h6' sx={{ my: 8 }}>
            Commission Details
            </Typography>
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Commission Percent' onChange={(e) => setCommision(e.target.value)} value={commision} placeholder='Commission Percent' />
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Credit Limit' onChange={(e) => setCreditLimit(e.target.value)} value={creditLimit} placeholder='Credit Limit' />
            </Grid>
            <Grid item xs={12}>
              <Button variant='contained' sx={{ mr: 2 }} onClick={submitProfileHandler}>
                Submit
              </Button>
            </Grid>



          </Grid>
        </CardContent>
      </Card>
    </>
  )
}

export default AddNewVendor
