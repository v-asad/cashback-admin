import Box from '@mui/material/Box'
import Tab from '@mui/material/Tab'
import TabContext from '@mui/lab/TabContext'
import TabList from '@mui/lab/TabList'
import TabPanel from '@mui/lab/TabPanel'
import Typography from '@mui/material/Typography'
import Avatar from '@mui/material/Avatar'
import Grid from '@mui/material/Grid'
import CardContent from '@mui/material/CardContent'
import Image from 'next/image'
import Button from '@mui/material/Button'
import { useState } from 'react'
import Card from '@mui/material/Card'
import fullscreen from 'src/store/fullscreen'
const OurVendor = () => {
  const [value, setValue] = useState('1')

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  return (
    <>
      <Typography variant='h5'>Vendor List</Typography>
      <Box sx={{ width: '100%', typography: 'body1' }}>
        <TabContext value={value}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <TabList onChange={handleChange} aria-label='lab API tabs example'>
              <Tab label='All' value='1' />
              <Tab label='Grocery' value='2' />
              <Tab label='Textiles' value='3' />
              <Tab label='Pharmacy' value='4' />
              <Tab label='Supermarket' value='5' />
              <Tab label='Resturants' value='6' />
              <Tab label='Coffee' value='7' />
              <Tab label='E Marketing' value='8' />
            </TabList>
          </Box>
          <TabPanel value='1'>
            <h4>All Vendors List</h4>
            <Grid container spacing={2} className='match-height'>
              <Grid item xs={12} md={4}>
                <Card component='div' sx={{ position: 'relative', mb: 7 }}>
                  <CardContent sx={{ display: 'flex' }}>
                   
                    <Grid item xs={12} md={6}>
                      <Image
                        className='avtarimg'
                        src='/images/avatars/1.png'
                        width={200}
                        height={200}
                        alt='Profile Picture'
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                    <Typography
                      component='div'
                      variant='p'
                      sx={{
                        fontWeight: 'bold',
                        mb: 10,
                        display: 'flex',
                        justifyContent: 'space-between',
                        flexDirection: 'column',
                        height:'50%'
                      }}
                    >
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>ID</span>
                        <span>Emark36922</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Name</span>
                        <span>Pizza</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Number</span>
                        <span>7905929530</span>
                      </Typography>
                      
                    </Typography>
                    </Grid>
                   
                  </CardContent>
                   <Grid item xs={12}  sx={{px:5,width:'100%'}}>
                   <Typography sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between' }}>
                        <Button variant="outlined">View Locations</Button>
                        <Button variant="contained">View Details</Button>
                      </Typography>
                    </Grid>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
              <Card component='div' sx={{ position: 'relative', mb: 7 }}>
                  <CardContent sx={{ display: 'flex' }}>
                   
                    <Grid item xs={12} md={6}>
                      <Image
                        className='avtarimg'
                        src='/images/avatars/1.png'
                        width={200}
                        height={200}
                        alt='Profile Picture'
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                    <Typography
                      component='div'
                      variant='p'
                      sx={{
                        fontWeight: 'bold',
                        mb: 10,
                        display: 'flex',
                        justifyContent: 'space-between',
                        flexDirection: 'column',
                        height:'50%'
                      }}
                    >
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>ID</span>
                        <span>Emark36922</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Name</span>
                        <span>Pizza</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Number</span>
                        <span>7905929530</span>
                      </Typography>
                      
                    </Typography>
                    </Grid>
                   
                  </CardContent>
                   <Grid item xs={12}  sx={{px:5,width:'100%'}}>
                   <Typography sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between' }}>
                        <Button variant="outlined">View Locations</Button>
                        <Button variant="contained">View Details</Button>
                      </Typography>
                    </Grid>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
              <Card component='div' sx={{ position: 'relative', mb: 7 }}>
                  <CardContent sx={{ display: 'flex' }}>
                   
                    <Grid item xs={12} md={6}>
                      <Image
                        className='avtarimg'
                        src='/images/avatars/1.png'
                        width={200}
                        height={200}
                        alt='Profile Picture'
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                    <Typography
                      component='div'
                      variant='p'
                      sx={{
                        fontWeight: 'bold',
                        mb: 10,
                        display: 'flex',
                        justifyContent: 'space-between',
                        flexDirection: 'column',
                        height:'50%'
                      }}
                    >
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>ID</span>
                        <span>Emark36922</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Name</span>
                        <span>Pizza</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Number</span>
                        <span>7905929530</span>
                      </Typography>
                      
                    </Typography>
                    </Grid>
                   
                  </CardContent>
                   <Grid item xs={12}  sx={{px:5,width:'100%'}}>
                   <Typography sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between' }}>
                        <Button variant="outlined">View Locations</Button>
                        <Button variant="contained">View Details</Button>
                      </Typography>
                    </Grid>
                </Card>
              </Grid>
              <Grid item xs={12} md={4}>
              <Card component='div' sx={{ position: 'relative', mb: 7 }}>
                  <CardContent sx={{ display: 'flex' }}>
                   
                    <Grid item xs={12} md={6}>
                      <Image
                        className='avtarimg'
                        src='/images/avatars/1.png'
                        width={200}
                        height={200}
                        alt='Profile Picture'
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                    <Typography
                      component='div'
                      variant='p'
                      sx={{
                        fontWeight: 'bold',
                        mb: 10,
                        display: 'flex',
                        justifyContent: 'space-between',
                        flexDirection: 'column',
                        height:'50%'
                      }}
                    >
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>ID</span>
                        <span>Emark36922</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Name</span>
                        <span>Pizza</span>
                      </Typography>
                      <Typography component='div' variant='p' sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between', }}>
                        <span>Number</span>
                        <span>7905929530</span>
                      </Typography>
                      
                    </Typography>
                    </Grid>
                   
                  </CardContent>
                   <Grid item xs={12}  sx={{px:5,width:'100%'}}>
                   <Typography sx={{ fontWeight: 'bold',display:'flex',justifyContent: 'space-between' }}>
                        <Button variant="outlined">View Locations</Button>
                        <Button variant="contained">View Details</Button>
                      </Typography>
                    </Grid>
                </Card>
              </Grid>
            </Grid>
          </TabPanel>
          <TabPanel value='2'>
            <h4>Grocery Vendors List</h4>
          </TabPanel>
          <TabPanel value='3'>
            <h4>Textiles Vendors List</h4>
          </TabPanel>
          <TabPanel value='4'>
            <h4>Pharmacy Vendors List</h4>
          </TabPanel>
          <TabPanel value='5'>
            <h4>Supermarket Vendors List</h4>
          </TabPanel>
          <TabPanel value='6'>
            <h4>Resturant Vendors List</h4>
          </TabPanel>
          <TabPanel value='7'>
            <h4>Coffee Vendors List</h4>
          </TabPanel>
          <TabPanel value='8'>
            <h4>E-Marketing Vendors List</h4>
          </TabPanel>
        </TabContext>
      </Box>
    </>
  )
}

export default OurVendor
