
import TextField from '@mui/material/TextField'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { DataGrid } from '@mui/x-data-grid'
import Card from '@mui/material/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from 'src/hooks/useAuth'
import CardContent from '@mui/material/CardContent'
import Icon from 'src/@core/components/icon'
import { toast } from 'react-hot-toast'
const AddNewService= () => {
  const auth = useAuth()
  const [data, setData] = useState([])
  const [service, setService] = useState(null)
  const loadData = () => {
    axios.get(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/vendor/services`, {
      headers: {
        "Authorization": `Bearer ${localStorage.accessToken}`
      }
    }).then(response=>{
      const tempData = response.data.map((d, key) => {
        return { key, ...d }
      })
      setData(tempData)
    }).catch(error => {
      toast.error(`${error.response? error.response.status:''}: ${error.response?error.response.data.message:error}`);
      if (error.response && error.response.status == 401) {
        auth.logout();
      }
    })
  }
  useEffect(()=>{
    loadData()
  }, [])
  const deleteService = (id) => {
    if(id){
      axios.delete(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/vendor/services/${id}`, {
        headers: {
          "Authorization": `Bearer ${localStorage.accessToken}`
        }
      })
        .then(resp => {
          let data = resp.data
          setService('')
          if(data.success){
            toast.success(data.message)
            const tempData = data.services.map((d, key) => {
              return { key, ...d }
            })
            setData(tempData)
          }else{
            toast.error(data.message)
          }
        })
        .catch(error => {
          if(error.response && error.response.data){
            if(error.response.data && error.response.data.message){
              toast.error(`${error.response? error.response.status:''}: ${error.response?error.response.data.message:error}`);
            }
            if(error.response.data && error.response.data.errors){
              error.response.data.errors.map(err => toast.error(err.msg))
            }
          }
          if (error.response && error.response.status == 401) {
            auth.logout();
          }
        })
    }
  }

  const createService = () => {
    if(service) {
      axios.post(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/vendor/services`, {
        service_name : service
      }, {
        headers: {
          "Authorization": `Bearer ${localStorage.accessToken}`
        }
      })
        .then(resp => {
          let data = resp.data
          setService('')
          if(data.success){
            toast.success(data.message)
            const tempData = data.services.map((d, key) => {
              return { key, ...d }
            })
            setData(tempData)
          }else{
            toast.error(data.message)
          }
        })
        .catch(error => {
          if(error.response && error.response.data){
            if(error.response.data && error.response.data.message){
              toast.error(`${error.response? error.response.status:''}: ${error.response?error.response.data.message:error}`);
            }
            if(error.response.data && error.response.data.errors){
              error.response.data.errors.map(err => toast.error(err.msg))
            }
          }
          if (error.response && error.response.status == 401) {
            auth.logout();
          }
        })
    }
  }
  const columns = [
    { field: '', headerName: '#', width: 100, renderCell: params => params.row.key + 1 },
    { field: 'service_name', headerName: 'Service Name', width: 400 },
    {
      field: 'date',
      headerName: 'Date',
      width: 300,
      renderCell: params => {
        // convert date here
        const updatedValue = new Date(params.row.date).toLocaleDateString()

        // when completed, return the column data
        return updatedValue
      }
    },
    {
      field: 'action',
      headerName: 'Action',
      width: 200,
      renderCell: params => {
        return <Button variant='contained' sx={{ mr: 2 }} onClick={()=>{
          deleteService(params.row.id)
        }}>Delete Service</Button>
      }
    }
  ]
  return (
    <>
   

      <Grid container spacing={3} >
      <Grid item  xs={12}>
            <Typography variant='h6' sx={{ my: 3 }}>
            Add Services
            </Typography>
            </Grid>
            <Grid item md={6} xs={12}>
              <TextField fullWidth label='Service' onChange={(e) => setService(e.target.value)} value={service} placeholder='Service' />
            </Grid>
            <Grid item xs={12}>
              <Button variant='contained' sx={{ mr: 2 }} onClick={createService}>
                Add Service
              </Button>
            </Grid>
            <Grid item xs={12}>
                  <Card component='div' sx={{ position: 'relative', mt: 20, }}>
      <CardContent>
         <DataGrid rows={data} columns={columns} pageSize={10}  getRowId={(row) => row.key}rowsPerPageOptions={[10]} autoHeight />
         </CardContent>
      </Card>
            </Grid>
        
      </Grid>
      
      
    </>
  )
}

export default AddNewService


      