import TextField from '@mui/material/TextField'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { DataGrid } from '@mui/x-data-grid'
import Card from '@mui/material/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from 'src/hooks/useAuth'
import CardContent from '@mui/material/CardContent'
import Checkbox from '@mui/material/Checkbox'
import TextareaAutosize from '@mui/base/TextareaAutosize'
import { styled } from '@mui/system'
import Icon from 'src/@core/components/icon'
import { toast } from 'react-hot-toast'
import Link from '@mui/material/Link'
const OpenWithdrawalRequest = () => {
  const blue = {
    100: '#DAECFF',
    200: '#b6daff',
    400: '#3399FF',
    500: '#007FFF',
    600: '#0072E5',
    900: '#003A75'
  }

  const grey = {
    50: '#f6f8fa',
    100: '#eaeef2',
    200: '#d0d7de',
    300: '#afb8c1',
    400: '#8c959f',
    500: '#6e7781',
    600: '#57606a',
    700: '#424a53',
    800: '#32383f',
    900: '#24292f'
  }

  const StyledTextarea = styled(TextareaAutosize)(
    ({ theme }) => `
    width: 320px;
    font-family: IBM Plex Sans, sans-serif;
    font-size: 0.875rem;
    font-weight: 400;
    line-height: 1.5;
    padding: 12px;
    border-radius: 12px 12px 0 12px;
    color: ${theme.palette.mode === 'dark' ? grey[300] : grey[900]};
    background: ${theme.palette.mode === 'dark' ? grey[900] : '#fff'};
    border: 1px solid ${theme.palette.mode === 'dark' ? grey[700] : grey[200]};
    box-shadow: 0px 2px 24px ${theme.palette.mode === 'dark' ? blue[900] : blue[100]};
  
    &:hover {
      border-color: ${blue[400]};
    }
  
    &:focus {
      border-color: ${blue[400]};
      box-shadow: 0 0 0 3px ${theme.palette.mode === 'dark' ? blue[600] : blue[200]};
    }
  
    // firefox
    &:focus-visible {
      outline: 0;
    }
  `
  )

  const auth = useAuth()
  const [data, setData] = useState([])
  const loadData = () => {
    axios
      .get(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/withdrawal-request/open`, {
        headers: {
          Authorization: `Bearer ${localStorage.accessToken}`
        }
      })
      .then(response => {
        const tempData = response.data.map((d, key) => {
          return { key, ...d }
        })
        setData(tempData)
      })
      .catch(error => {
        toast.error(
          `${error.response ? error.response.status : ''}: ${error.response ? error.response.data.message : error}`
        )
        if (error.response && error.response.status == 401) {
          auth.logout()
        }
      })
  }
  useEffect(() => {
    loadData()
  }, [])
  const columns = [
    { field: '', headerName: '#', width: 100, renderCell: params => params.row.key + 1 },
    { field: 'user_id', headerName: 'User Id', width: 200 },
    {
      field: 'check',
      headerName: 'Select',
      width: 200,
      renderCell: params => {
        return (
          <Link>
            <Checkbox />
          </Link>
        )
      }
    },
    {
      field: 'full_name',
      headerName: 'fullName',
      width: 250,
      renderCell: params => `${params.row.first_name} ${params.row.last_name}`
    },
    { field: 'request_amount', headerName: 'request amount', width: 200 },

    { field: 'transaction_number', headerName: 'Transaction Number', width: 150 },

    { field: 'bank_nm', headerName: 'bank name', width: 150 },
    { field: 'acc_number', headerName: 'acc_number', width: 150 },
    { field: 'swift_code', headerName: 'swift_code', width: 150 },
    {
      field: 'posted_date',
      headerName: 'posted_date',
      width: 150,
      renderCell: params => new Date(params.row.posted_date).toLocaleDateString()
    }
  ]
  return (
    <>
      <Grid item xs={12}>
        <Box>
          <Typography variant='h5' sx={{ my: 8 }}>
            Open Withdraw Request
          </Typography>
        </Box>
      </Grid>

      <Card component='div' sx={{ position: 'relative', mb: 7 }}>
        <CardContent>
          <DataGrid
            rows={data}
            columns={columns}
            pageSize={10}
            getRowId={row => row.key}
            rowsPerPageOptions={[10]}
            autoHeight
          />
        </CardContent>
      </Card>
      <Grid item xs={12} md={4}>
        <Card component='div' sx={{ position: 'relative', mb: 7 }}>
          <CardContent sx={{ display: 'flex', justifyContent: 'center',alignItems:'flex-end' }}>
            <StyledTextarea aria-label='minimum height' minRows={5} placeholder='Minimum 3 rows' />
            <Button variant='contained' sx={{ ml: 2,height:'50px' }}>
                Submit
              </Button>
          </CardContent>
        </Card>
      </Grid>
    </>
  )
}

export default OpenWithdrawalRequest
