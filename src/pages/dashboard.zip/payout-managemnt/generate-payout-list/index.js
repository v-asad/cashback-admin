import TextField from '@mui/material/TextField'
import Grid from '@mui/material/Grid'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import { DataGrid } from '@mui/x-data-grid'
import Card from '@mui/material/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { useAuth } from 'src/hooks/useAuth'
import CardContent from '@mui/material/CardContent'
import Icon from 'src/@core/components/icon'
import { toast } from 'react-hot-toast'
const GeneratePayoutList = () => {
  const auth = useAuth()
  const [data, setData] = useState([])
  const loadData = () => {
    axios
      .get(`${process.env.NEXT_PUBLIC_API_URL}/controlpanel/payout-mgt/generate-payout-list`, {
        headers: {
          Authorization: `Bearer ${localStorage.accessToken}`
        }
      })
      .then(response => {
        const tempData = response.data.data.map((d, key) => {
          return { key, ...d }
        })
        setData(tempData)
      })
      .catch(error => {
        toast.error(
          `${error.response ? error.response.status : ''}: ${error.response ? error.response.data.message : error}`
        )
        if (error.response && error.response.status == 401) {
          auth.logout()
        }
      })
  }
  useEffect(() => {
    loadData()
  }, [])
  const columns = [
    { field: '', headerName: '#', width: 100, renderCell: params => params.row.key + 1 },
    { field: 'userId', headerName: 'User Id', width: 200 },
    {
      field: 'fullName',
      headerName: 'fullName',
      width: 250,
      
    },
    { field: 'packagename', headerName: 'Member Name', width: 200, renderCell: params => `${ params.row.package.name } [${ params.row.package.amount }]` },
    
    {
      field: 'selfPurchase',
      headerName: 'Self Purchase',
      width: 150,
      
    },
    { field: 'levelIncome', headerName: 'Level Income', width: 150,  },
    { field: 'coFounderIncome', headerName: 'Co Founder Income', width: 150, },
    { field: 'total', headerName: 'Total', width: 150, },
  ]
  return (
    <>
      <Grid item xs={12}>
        <Box>
          <Typography variant='h5' sx={{ my: 8 }}>
            Current Payout Report{' '}
          </Typography>
        </Box>
      </Grid>
      <Grid item xs={12}>
        <Button variant='contained' sx={{ mr: 2,mb:10 }}>
          Generate
        </Button>
      </Grid>

      <Card component='div' sx={{ position: 'relative', mb: 7 }}>
        <CardContent>
          <DataGrid
            rows={data}
            columns={columns}
            pageSize={10}
            getRowId={row => row.key}
            rowsPerPageOptions={[10]}
            autoHeight
          />
        </CardContent>
      </Card>
    </>
  )
}

export default GeneratePayoutList
